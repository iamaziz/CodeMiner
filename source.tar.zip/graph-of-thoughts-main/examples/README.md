# Examples

This directory contains scripts for running various examples using the Graph of Thoughts package. Each script is a standalone Python program that sets up and runs a particular example.

Please refer to the individual example directories for more information on the specific example.

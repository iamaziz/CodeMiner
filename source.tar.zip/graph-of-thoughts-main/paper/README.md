## Plot Data

The data used to create the figure of the arXiv preprint article can be
found in the `final_results_gpt35.tar.bz2` archive.  Unpack the archive
and run the file `plots.py`.
